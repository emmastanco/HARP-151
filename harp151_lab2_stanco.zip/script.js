var username = prompt("What is your name?");
let placeholder = document.getElementById("username");
placeholder.textContent= username;



document.getElementById("changeGreena").onclick = function(){
	document.getElementById("outputa").style.color = 'green';
}

document.getElementById("changeGreenb").onclick = function(){
	document.getElementById("outputb").style.color = 'green';
}

document.getElementById("changeGreenc").onclick = function(){
	document.getElementById("outputc").style.color = 'green';
}

document.getElementById("changeGreend").onclick = function(){
	document.getElementById("outputd").style.color = 'green';
}

document.getElementById("changeGreene").onclick = function(){
	document.getElementById("outpute").style.color = 'green';
}